Cria.Ai Anúncios - README

Siga .env.example, npm install, npx prisma generate, npx prisma migrate dev --name init, npm run dev

Deploy: push to GitHub and import in Vercel, set env vars, run npx prisma migrate deploy before first start.
